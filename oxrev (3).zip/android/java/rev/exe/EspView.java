package rev.exe;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/** Full-screen overlay: north-up radar (no camera forward/FOV offset was confirmed in this dump, so no
 *  world-to-screen box ESP -- this draws what the confirmed data (positions, names, friend/team flags) supports)
 *  plus a distance-sorted name list. */
public class EspView extends View {
    private final Paint pDot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pRing = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pBg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pLocal = new Paint(Paint.ANTI_ALIAS_FLAG);

    public EspView(Context c) {
        super(c);
        pRing.setStyle(Paint.Style.STROKE);
        pRing.setStrokeWidth(2f);
        pRing.setColor(0x55FFFFFF);
        pText.setTextSize(28f);
        pText.setColor(Color.WHITE);
        pBg.setColor(0x99101215);
        pLocal.setColor(Color.WHITE);
        setWillNotDraw(false);
        postInvalidateLoop();
    }

    private void postInvalidateLoop() {
        postInvalidateDelayed(33);
        postDelayed(this::postInvalidateLoop, 33);
    }

    private int colorFor(Player p) {
        if (p.friendly()) return Cfg.col("friendCol");
        if (p.teammate()) return Cfg.col("teamCol");
        return Cfg.col("enemyCol");
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Snap s = Model.snap;
        float W = getWidth(), H = getHeight();
        boolean stale = (System.nanoTime() - s.t) > 1_500_000_000L;

        // status line
        String st = (s.ok ? "ok" : "N:") + " " + s.status + (stale ? " (stale)" : "");
        canvas.drawRect(0, H - 56, 420, H, pBg);
        pText.setTextSize(24f);
        pText.setColor(0xFF9FD3FF);
        canvas.drawText(st, 12, H - 20, pText);

        if (!s.ok || !s.haveLocal) return;

        ArrayList<Player> list = new ArrayList<>();
        for (Player p : s.players) {
            if (p.local()) continue;
            if (Cfg.b("hideFriend") && p.friendly()) continue;
            if (Cfg.b("hideTeam") && p.teammate()) continue;
            if (Model.dist(s, p) > Cfg.f("maxDist")) continue;
            list.add(p);
        }
        if (Cfg.b("sortNear")) Collections.sort(list, Comparator.comparingDouble(p -> Model.dist(s, p)));

        // ---- radar: north-up (no camera yaw offset available), local at center
        if (Cfg.b("radar")) {
            float size = Cfg.f("radarSize"), range = Math.max(10f, Cfg.f("radarRange"));
            float cx = W - size / 2f - 16f, cy = size / 2f + 16f;
            canvas.drawCircle(cx, cy, size / 2f, pBg);
            canvas.drawCircle(cx, cy, size / 2f, pRing);
            canvas.drawCircle(cx, cy, 5f, pLocal);
            for (Player p : list) {
                float dx = p.x - s.lx, dz = p.z - s.lz;
                float d = (float) Math.sqrt(dx * dx + dz * dz);
                float scale = Math.min(1f, d / range);
                float rx = d < 1e-3f ? 0 : dx / d, rz = d < 1e-3f ? 0 : dz / d;
                float px = cx + rx * scale * (size / 2f - 6f);
                float py = cy - rz * scale * (size / 2f - 6f);
                pDot.setColor(colorFor(p));
                canvas.drawCircle(px, py, 5f, pDot);
            }
        }

        // ---- distance-sorted name list
        if (Cfg.b("esp") && (Cfg.b("name") || Cfg.b("dist"))) {
            float y = 40f;
            pText.setTextSize(26f);
            for (Player p : list) {
                float d = Model.dist(s, p);
                StringBuilder line = new StringBuilder();
                if (Cfg.b("name")) line.append(p.name.isEmpty() ? "?" : p.name);
                if (Cfg.b("dist")) { if (line.length() > 0) line.append("  "); line.append((int) d).append("m"); }
                pText.setColor(colorFor(p));
                canvas.drawText(line.toString(), 12, y, pText);
                y += 30f;
                if (y > H - 70) break;
            }
        }
    }
}
