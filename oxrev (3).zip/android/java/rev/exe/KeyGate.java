package rev.exe;

import android.content.Context;
import android.content.SharedPreferences;

import java.security.MessageDigest;

/** One shared key for everyone. No server, no HWID, no network -- local hash compare only.
 *  Rotate: change KEY_SHA256 to sha256(NEW_KEY.toUpperCase()), tell people the new key. */
final class KeyGate {
    private static final String PREFS = "rev_lic";

    // sha256("REVOLT-ORBIT-4K2P")
    private static final String KEY_SHA256 = "dcd85975bda6bd9b2ff2c05afbcd057d4a4f8243860690e41752129c8a2cf564";

    static final class Result {
        final boolean ok;
        final String reason; // "ok" | "format" | "bad_key"
        Result(boolean ok, String reason) { this.ok = ok; this.reason = reason; }
    }

    private static SharedPreferences sp(Context ctx) { return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    private static String sha256Hex(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(s.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    static boolean quickCheck(Context ctx) {
        return sp(ctx).getBoolean("unlocked", false);
    }

    static Result check(Context ctx, String rawKey) {
        if (rawKey == null || rawKey.trim().isEmpty()) return new Result(false, "format");
        String key = rawKey.trim().toUpperCase(java.util.Locale.US);
        boolean ok = sha256Hex(key).equals(KEY_SHA256);
        if (ok) sp(ctx).edit().putBoolean("unlocked", true).apply();
        return new Result(ok, ok ? "ok" : "bad_key");
    }

    // ---- local token for oxrev_core: same HMAC construction as src/authtok.cpp ----
    private static final byte MASK = (byte) 0x5A;
    private static final byte[] S1 = {0x3a, 0x02, 0x63, 0x58, 0x7d, 0x0d, 0x60, 0x5c};
    private static final byte[] S2 = {0x29, 0x1a, 0x7b, 0x49, 0x6e, 0x12, 0x71, 0x4f};

    private static byte[] secret() {
        byte[] out = new byte[S1.length + S2.length];
        for (int i = 0; i < S1.length; i++) out[i] = (byte) (S1[i] ^ MASK);
        for (int i = 0; i < S2.length; i++) out[S1.length + i] = (byte) (S2[i] ^ MASK);
        return out;
    }

    static String coreTokenLine(Context ctx) {
        long day = System.currentTimeMillis() / 86400000L;
        String dayStr = Long.toString(day);
        String hwid = "local";
        String token = hmacHex(hwid + "|" + dayStr);
        return "K|" + hwid + "|" + dayStr + "|" + token + "\n";
    }

    private static String hmacHex(String msg) {
        try {
            javax.crypto.Mac m = javax.crypto.Mac.getInstance("HmacSHA256");
            m.init(new javax.crypto.spec.SecretKeySpec(secret(), "HmacSHA256"));
            byte[] full = m.doFinal(msg.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 8; i++) sb.append(String.format("%02x", full[i]));
            return sb.toString();
        } catch (Exception e) {
            return "0000000000000000";
        }
    }
}
