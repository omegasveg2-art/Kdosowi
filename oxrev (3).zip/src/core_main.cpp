// oxrev_core: root, read-only memory reader (ESP only -- no confirmed aim/weapon offsets for this dump yet). Talks to the
// overlay APK over stdin/stdout.
// usage: oxrev_core [-p <pkg substring>] [--base 0x<libil2cpp base>]
// out:  S|ok|haveLocal|lx,ly,lz|obj,flags,x,y,z,name;...   (flags: 1 local, 2 friend, 4 teammate)
//       N|status
// in:   K|hwid|dayEpoch|tokenHex
#include "authtok.h"
#include "game.h"
#include "mem.h"
#include <chrono>
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <string>
#include <thread>
#include <unistd.h>

static std::mutex g_mu;
static volatile bool g_quit = false;
static void on_signal(int) { g_quit = true; }
static volatile bool g_tokenOk = false;

static void stdin_loop() {
    char line[512];
    while (fgets(line, sizeof line, stdin)) {
        if (line[0] == 'K' && line[1] == '|') {
            char buf[512];
            strncpy(buf, line + 2, sizeof buf - 1); buf[sizeof buf - 1] = 0;
            char* save = nullptr;
            char* hwid = strtok_r(buf, "|\r\n", &save);
            char* day  = strtok_r(nullptr, "|\r\n", &save);
            char* tok  = strtok_r(nullptr, "|\r\n", &save);
            if (hwid && day && tok && authtok_verify(hwid, day, tok)) g_tokenOk = true;
        }
    }
    g_quit = true;
}

static std::string clean(const char* s) {
    std::string o;
    for (; *s; s++) o.push_back((isalnum((unsigned char)*s) || *s == '_' || *s == '.' || *s == '-' || *s == ' ') ? *s : '_');
    return o;
}

int main(int argc, char** argv) {
    std::string pkg = "oxide";
    uint64_t baseOverride = 0;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-p") && i + 1 < argc) pkg = argv[++i];
        else if (!strcmp(argv[i], "--base") && i + 1 < argc) baseOverride = strtoull(argv[++i], nullptr, 16);
    }
    if (getuid() != 0) { printf("N|needs root\n"); return 1; }
    setvbuf(stdout, nullptr, _IOLBF, 0);
    signal(SIGTERM, on_signal); signal(SIGINT, on_signal); signal(SIGHUP, on_signal); signal(SIGPIPE, SIG_IGN);
    std::thread(stdin_loop).detach();

    {
        auto t0 = std::chrono::steady_clock::now();
        while (!g_tokenOk && !g_quit && std::chrono::steady_clock::now() - t0 < std::chrono::seconds(5))
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
        if (!g_tokenOk) return 0;
    }

    Proc proc;
    Game* game = nullptr;
    Snapshot snap;
    std::string status = "waiting for game";
    auto lastTry = std::chrono::steady_clock::now() - std::chrono::seconds(10);

    for (;;) {
        if (g_quit) return 0;
        if (game && !proc.alive()) { delete game; game = nullptr; proc.detach(); status = "game closed"; }
        if (!game && std::chrono::steady_clock::now() - lastTry > std::chrono::seconds(2)) {
            lastTry = std::chrono::steady_clock::now();
            int pid = Proc::find_pid(pkg);
            if (pid) {
                proc.attach(pid);
                uint64_t base = baseOverride ? baseOverride : proc.module_base("libil2cpp.so");
                if (base) game = new Game(proc, base);
                else { proc.detach(); status = "libil2cpp.so not mapped (use --base)"; }
            }
        }
        if (!game) { printf("N|%s\n", status.c_str()); std::this_thread::sleep_for(std::chrono::milliseconds(500)); continue; }
        if (!game->update(snap)) { printf("N|%s\n", game->status()); std::this_thread::sleep_for(std::chrono::milliseconds(150)); continue; }

        std::string out = "S|ok|";
        char b[256];
        snprintf(b, sizeof b, "%d|%.3f,%.3f,%.3f|", snap.haveLocal ? 1 : 0, snap.localPos.x, snap.localPos.y, snap.localPos.z);
        out += b;
        bool first = true;
        for (auto& p : snap.players) {
            snprintf(b, sizeof b, "%s%llu,%d,%.3f,%.3f,%.3f,", first ? "" : ";", (unsigned long long)p.obj,
                     (p.local ? 1 : 0) | (p.friendly ? 2 : 0) | (p.teammate ? 4 : 0), p.pos.x, p.pos.y, p.pos.z);
            out += b; out += clean(p.name);
            first = false;
        }
        out += "\n";
        if (fputs(out.c_str(), stdout) < 0) return 0;
        std::this_thread::sleep_for(std::chrono::milliseconds(16));
    }
}
