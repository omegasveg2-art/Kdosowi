#include "game.h"
#include "offsets.h"
#include <chrono>
#include <cmath>
#include <cstring>

static double now_s() {
    using namespace std::chrono;
    return duration<double>(steady_clock::now().time_since_epoch()).count();
}
static bool finite3(Vec3 v) { return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z); }

bool Game::resolve() {
    if (!kPM_)    kPM_    = il_.klass(off::PlayerManager::cls);
    if (!kYd_)    kYd_    = il_.klass(off::Yd::cls);
    if (!kText_)  kText_  = il_.klass(off::UIText::cls);
    if (!kNetId_) kNetId_ = il_.klass(off::NetworkIdentity::cls);
    status_ = !kPM_ ? "no PlayerManager class (il2cpp structs seen: " + std::to_string(il_.classes_seen()) + ")" : "ok";
    return kPM_ != 0;
}

// Unity native Transform -> world position (64-bit, Unity 2019-2022 layout). Same walk as cf_esp's.
bool Game::world_pos(uint64_t tr, Vec3& out) { return world_pos_nat(rdp(m_, tr + 0x10), out); }

bool Game::world_pos_nat(uint64_t nat, Vec3& out) {
    if (!plausible_ptr(nat)) return false;
    uint64_t hier = rdp(m_, nat + 0x38);
    int idx = (int)rd32(m_, nat + 0x40);
    if (!plausible_ptr(hier) || idx < 0 || idx > 200000) return false;
    uint64_t list = rdp(m_, hier + 0x18), par = rdp(m_, hier + 0x20);
    if (!plausible_ptr(list) || !plausible_ptr(par)) return false;
    float t[12];
    if (!m_.read(list + 0x30ull * (uint64_t)idx, t, sizeof t)) return false;
    Vec3 r{t[0], t[1], t[2]};
    int cur = (int)rd32(m_, par + 4ull * (uint64_t)idx);
    for (int g = 0; cur >= 0 && g < 64; g++) {
        if (cur > 200000 || !m_.read(list + 0x30ull * (uint64_t)cur, t, sizeof t)) return false;
        Vec3 q{t[4], t[5], t[6]};
        float w = t[7];
        Vec3 sv{r.x * t[8], r.y * t[9], r.z * t[10]};
        Vec3 c1 = cross(q, sv);
        Vec3 c2 = cross(q, c1 + sv * w);
        r = Vec3{t[0], t[1], t[2]} + sv + c2 * 2.f;
        cur = (int)rd32(m_, par + 4ull * (uint64_t)cur);
    }
    if (!finite3(r)) return false;
    out = r;
    return true;
}

bool Game::update(Snapshot& s) {
    s.valid = false; s.haveLocal = false;
    s.players.clear();
    if (!kPM_ && !resolve()) return false;

    const double t = now_s();
    bool stale = players_.empty();
    for (uint64_t o : players_) if (rdp(m_, o) != kPM_) { stale = true; break; }
    if ((stale || t >= nextScan_)) {
        nextScan_ = t + 2.0;
        auto fresh = il_.find_instances(kPM_, [&](uint64_t o) {
            uint64_t cam = rdp(m_, o + off::PlayerManager::worldCameraRoot);
            return plausible_ptr(cam);
        });
        if (!fresh.empty() || stale) players_ = fresh;
    }
    if (players_.empty()) { status_ = "no PlayerManager instances yet (not in a match?)"; return false; }

    for (uint64_t o : players_) {
        if (rdp(m_, o) != kPM_) continue;
        PlayerInfo p;
        p.obj = o;
        uint64_t cam = rdp(m_, o + off::PlayerManager::worldCameraRoot);
        if (!plausible_ptr(cam) || !world_pos(cam, p.pos) || !finite3(p.pos)) continue;

        // local detection: NetworkBehaviour(vd).netIdentity -> NetworkIdentity.isOwned
        uint64_t ni = rdp(m_, o + off::NetworkBehaviour::netIdentity);
        if (kNetId_ && plausible_ptr(ni) && rdp(m_, ni) == kNetId_)
            p.local = rd8(m_, ni + off::NetworkIdentity::isOwned) != 0;

        // nametag: PlayerManager.nicklabel(Yd*) -> isFriend/isTeammate + nickname(Text*).m_Text
        uint64_t yd = rdp(m_, o + off::PlayerManager::nicklabel);
        if (kYd_ && plausible_ptr(yd) && rdp(m_, yd) == kYd_) {
            p.friendly = rd8(m_, yd + off::Yd::isFriend) != 0;
            p.teammate = rd8(m_, yd + off::Yd::isTeammate) != 0;
            uint64_t txt = rdp(m_, yd + off::Yd::nickname);
            if (kText_ && plausible_ptr(txt) && rdp(m_, txt) == kText_) {
                uint64_t str = rdp(m_, txt + off::UIText::m_Text);
                if (plausible_ptr(str)) {
                    std::string nm = il_.str(str);
                    strncpy(p.name, nm.c_str(), sizeof p.name - 1);
                }
            }
        }
        if (p.local) { s.haveLocal = true; s.localPos = p.pos; }
        s.players.push_back(p);
    }
    status_ = "ok";
    s.valid = true;
    return true;
}
